package service;

import java.util.List;

import org.springframework.stereotype.Service;

import entity.Product;


public interface ProductService {

	List<Product> searchProduct(String brand);
}
